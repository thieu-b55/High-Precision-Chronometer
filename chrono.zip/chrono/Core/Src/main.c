/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
struct tijd{
	uint16_t micro_seconden;
	uint16_t milli_seconden;
	uint16_t seconden;
	uint16_t minuten;
	uint16_t uren;
} chrono;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SPI_1_CS		GPIOA, GPIO_PIN_4
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/**
 * tabel voor omzetten hex naar bcd voor led display
 */
uint8_t tabel[1000][3] = {{0, 0, 0}, {0, 0, 1}, {0, 0, 2}, {0, 0, 3}, {0, 0, 4}, {0, 0, 5}, {0, 0, 6}, {0, 0, 7}, {0, 0, 8}, {0, 0, 9},
                       	  {0, 1, 0}, {0, 1, 1}, {0, 1, 2}, {0, 1, 3}, {0, 1, 4}, {0, 1, 5}, {0, 1, 6}, {0, 1, 7}, {0, 1, 8}, {0, 1, 9},
						  {0, 2, 0}, {0, 2, 1}, {0, 2, 2}, {0, 2, 3}, {0, 2, 4}, {0, 2, 5}, {0, 2, 6}, {0, 2, 7}, {0, 2, 8}, {0, 2, 9},
						  {0, 3, 0}, {0, 3, 1}, {0, 3, 2}, {0, 3, 3}, {0, 3, 4}, {0, 3, 5}, {0, 3, 6}, {0, 3, 7}, {0, 3, 8}, {0, 3, 9},
						  {0, 4, 0}, {0, 4, 1}, {0, 4, 2}, {0, 4, 3}, {0, 4, 4}, {0, 4, 5}, {0, 4, 6}, {0, 4, 7}, {0, 4, 8}, {0, 4, 9},
						  {0, 5, 0}, {0, 5, 1}, {0, 5, 2}, {0, 5, 3}, {0, 5, 4}, {0, 5, 5}, {0, 5, 6}, {0, 5, 7}, {0, 5, 8}, {0, 5, 9},
						  {0, 6, 0}, {0, 6, 1}, {0, 6, 2}, {0, 6, 3}, {0, 6, 4}, {0, 6, 5}, {0, 6, 6}, {0, 6, 7}, {0, 6, 8}, {0, 6, 9},
						  {0, 7, 0}, {0, 7, 1}, {0, 7, 2}, {0, 7, 3}, {0, 7, 4}, {0, 7, 5}, {0, 7, 6}, {0, 7, 7}, {0, 7, 8}, {0, 7, 9},
						  {0, 8, 0}, {0, 8, 1}, {0, 8, 2}, {0, 8, 3}, {0, 8, 4}, {0, 8, 5}, {0, 8, 6}, {0, 8, 7}, {0, 8, 8}, {0, 8, 9},
						  {0, 9, 0}, {0, 9, 1}, {0, 9, 2}, {0, 9, 3}, {0, 9, 4}, {0, 9, 5}, {0, 9, 6}, {0, 9, 7}, {0, 9, 8}, {0, 9, 9},
						  {1, 0, 0}, {1, 0, 1}, {1, 0, 2}, {1, 0, 3}, {1, 0, 4}, {1, 0, 5}, {1, 0, 6}, {1, 0, 7}, {1, 0, 8}, {1, 0, 9},
						  {1, 1, 0}, {1, 1, 1}, {1, 1, 2}, {1, 1, 3}, {1, 1, 4}, {1, 1, 5}, {1, 1, 6}, {1, 1, 7}, {1, 1, 8}, {1, 1, 9},
						  {1, 2, 0}, {1, 2, 1}, {1, 2, 2}, {1, 2, 3}, {1, 2, 4}, {1, 2, 5}, {1, 2, 6}, {1, 2, 7}, {1, 2, 8}, {1, 2, 9},
						  {1, 3, 0}, {1, 3, 1}, {1, 3, 2}, {1, 3, 3}, {1, 3, 4}, {1, 3, 5}, {1, 3, 6}, {1, 3, 7}, {1, 3, 8}, {1, 3, 9},
						  {1, 4, 0}, {1, 4, 1}, {1, 4, 2}, {1, 4, 3}, {1, 4, 4}, {1, 4, 5}, {1, 4, 6}, {1, 4, 7}, {1, 4, 8}, {1, 4, 9},
						  {1, 5, 0}, {1, 5, 1}, {1, 5, 2}, {1, 5, 3}, {1, 5, 4}, {1, 5, 5}, {1, 5, 6}, {1, 5, 7}, {1, 5, 8}, {1, 5, 9},
						  {1, 1, 0}, {1, 6, 1}, {1, 6, 2}, {1, 6, 3}, {1, 6, 4}, {1, 6, 5}, {1, 6, 6}, {1, 6, 7}, {1, 6, 8}, {1, 6, 9},
						  {1, 7, 0}, {1, 7, 1}, {1, 7, 2}, {1, 7, 3}, {1, 7, 4}, {1, 7, 5}, {1, 7, 6}, {1, 7, 7}, {1, 7, 8}, {1, 7, 9},
						  {1, 8, 0}, {1, 8, 1}, {1, 8, 2}, {1, 8, 3}, {1, 8, 4}, {1, 8, 5}, {1, 8, 6}, {1, 8, 7}, {1, 8, 8}, {1, 8, 9},
						  {1, 9, 0}, {1, 9, 1}, {1, 9, 2}, {1, 9, 3}, {1, 9, 4}, {1, 9, 5}, {1, 9, 6}, {1, 9, 7}, {1, 9, 8}, {1, 9, 9},
						  {2, 0, 0}, {2, 0, 1}, {2, 0, 2}, {2, 0, 3}, {2, 0, 4}, {2, 0, 5}, {2, 0, 6}, {2, 0, 7}, {2, 0, 8}, {2, 0, 9},
						  {2, 1, 0}, {2, 1, 1}, {2, 1, 2}, {2, 1, 3}, {2, 1, 4}, {2, 1, 5}, {2, 1, 6}, {2, 1, 7}, {2, 1, 8}, {2, 1, 9},
						  {2, 2, 0}, {2, 2, 1}, {2, 2, 2}, {2, 2, 3}, {2, 2, 4}, {2, 2, 5}, {2, 2, 6}, {2, 2, 7}, {2, 2, 8}, {2, 2, 9},
						  {2, 3, 0}, {2, 3, 1}, {2, 3, 2}, {2, 3, 3}, {2, 3, 4}, {2, 3, 5}, {2, 3, 6}, {2, 3, 7}, {2, 3, 8}, {2, 3, 9},
						  {2, 4, 0}, {2, 4, 1}, {2, 4, 2}, {2, 4, 3}, {2, 4, 4}, {2, 4, 5}, {2, 4, 6}, {2, 4, 7}, {2, 4, 8}, {2, 4, 9},
						  {2, 5, 0}, {2, 5, 1}, {2, 5, 2}, {2, 5, 3}, {2, 5, 4}, {2, 5, 5}, {2, 5, 6}, {2, 5, 7}, {2, 5, 8}, {2, 5, 9},
						  {2, 6, 0}, {2, 6, 1}, {2, 6, 2}, {2, 6, 3}, {2, 6, 4}, {2, 6, 5}, {2, 6, 6}, {2, 6, 7}, {2, 6, 8}, {2, 6, 9},
						  {2, 7, 0}, {2, 7, 1}, {2, 7, 2}, {2, 7, 3}, {2, 7, 4}, {2, 7, 5}, {2, 7, 6}, {2, 7, 7}, {2, 7, 8}, {2, 7, 9},
						  {2, 8, 0}, {2, 8, 1}, {2, 8, 2}, {2, 8, 3}, {2, 8, 4}, {2, 8, 5}, {2, 8, 6}, {2, 8, 7}, {2, 8, 8}, {2, 8, 9},
						  {2, 9, 0}, {2, 9, 1}, {2, 9, 2}, {2, 9, 3}, {2, 9, 4}, {2, 9, 5}, {2, 9, 6}, {2, 9, 7}, {2, 9, 8}, {2, 9, 9},
						  {3, 0, 0}, {3, 0, 1}, {3, 3, 2}, {3, 0, 3}, {3, 0, 4}, {3, 0, 5}, {3, 0, 6}, {3, 0, 7}, {3, 0, 8}, {3, 0, 9},
						  {3, 1, 0}, {3, 1, 1}, {3, 1, 2}, {3, 1, 3}, {3, 1, 4}, {3, 1, 5}, {3, 1, 6}, {3, 1, 7}, {3, 1, 8}, {3, 1, 9},
						  {3, 2, 0}, {3, 2, 1}, {3, 2, 2}, {3, 2, 3}, {3, 2, 4}, {3, 2, 5}, {3, 2, 6}, {3, 2, 7}, {3, 2, 8}, {3, 2, 9},
						  {3, 3, 0}, {3, 3, 1}, {3, 3, 2}, {3, 3, 3}, {3, 3, 4}, {3, 3, 5}, {3, 3, 6}, {3, 3, 7}, {3, 3, 8}, {3, 3, 9},
						  {3, 4, 0}, {3, 4, 1}, {3, 4, 2}, {3, 4, 3}, {3, 4, 4}, {3, 4, 5}, {3, 4, 6}, {3, 4, 7}, {3, 4, 8}, {3, 4, 9},
						  {3, 5, 0}, {3, 5, 1}, {3, 5, 2}, {3, 5, 3}, {3, 5, 4}, {3, 5, 5}, {3, 5, 6}, {3, 5, 7}, {3, 5, 8}, {3, 5, 9},
						  {3, 6, 0}, {3, 6, 1}, {3, 6, 2}, {3, 6, 3}, {3, 6, 4}, {3, 6, 5}, {3, 6, 6}, {3, 6, 7}, {3, 6, 8}, {3, 6, 9},
						  {3, 7, 0}, {3, 7, 1}, {3, 7, 2}, {3, 7, 3}, {3, 7, 4}, {3, 7, 5}, {3, 7, 6}, {3, 7, 7}, {3, 7, 8}, {3, 7, 9},
						  {3, 8, 0}, {3, 8, 1}, {3, 8, 2}, {3, 8, 3}, {3, 8, 4}, {3, 8, 5}, {3, 8, 6}, {3, 8, 7}, {3, 8, 8}, {3, 8, 9},
						  {3, 9, 0}, {3, 9, 1}, {3, 9, 2}, {3, 9, 3}, {3, 9, 4}, {3, 9, 5}, {3, 9, 6}, {3, 9, 7}, {3, 9, 8}, {3, 9, 9},
						  {4, 0, 0}, {4, 0, 1}, {4, 0, 2}, {4, 0, 3}, {4, 0, 4}, {4, 0, 5}, {4, 0, 6}, {4, 0, 7}, {4, 0, 8}, {4, 0, 9},
						  {4, 1, 0}, {4, 1, 1}, {4, 1, 2}, {4, 1, 3}, {4, 1, 4}, {4, 1, 5}, {4, 1, 6}, {4, 1, 7}, {4, 1, 8}, {4, 1, 9},
						  {4, 2, 0}, {4, 2, 1}, {4, 2, 2}, {4, 2, 3}, {4, 2, 4}, {4, 2, 5}, {4, 2, 6}, {4, 2, 7}, {4, 2, 8}, {4, 2, 9},
						  {4, 3, 0}, {4, 3, 1}, {4, 3, 2}, {4, 3, 3}, {4, 3, 4}, {4, 3, 5}, {4, 3, 6}, {4, 3, 7}, {4, 3, 8}, {4, 3, 9},
						  {4, 4, 0}, {4, 4, 1}, {4, 4, 2}, {4, 4, 3}, {4, 4, 4}, {4, 4, 5}, {4, 4, 6}, {4, 4, 7}, {4, 4, 8}, {4, 4, 9},
						  {4, 5, 0}, {4, 5, 1}, {4, 5, 2}, {4, 5, 3}, {4, 5, 4}, {4, 5, 5}, {4, 5, 6}, {4, 5, 7}, {4, 5, 8}, {4, 5, 9},
						  {4, 6, 0}, {4, 6, 1}, {4, 6, 2}, {4, 6, 3}, {4, 6, 4}, {4, 6, 5}, {4, 6, 6}, {4, 6, 7}, {4, 6, 8}, {4, 6, 9},
						  {4, 7, 0}, {4, 7, 1}, {4, 7, 2}, {4, 7, 3}, {4, 7, 4}, {4, 7, 5}, {4, 7, 6}, {4, 7, 7}, {4, 7, 8}, {4, 7, 9},
						  {4, 8, 0}, {4, 8, 1}, {4, 8, 2}, {4, 8, 3}, {4, 8, 4}, {4, 8, 5}, {4, 8, 6}, {4, 8, 7}, {4, 8, 8}, {4, 8, 9},
						  {4, 9, 0}, {4, 9, 1}, {4, 9, 2}, {4, 9, 3}, {4, 9, 4}, {4, 9, 5}, {4, 9, 6}, {4, 9, 7}, {4, 9, 8}, {4, 9, 9},
						  {5, 0, 0}, {5, 0, 1}, {5, 0, 2}, {5, 0, 3}, {5, 0, 4}, {5, 0, 5}, {5, 0, 6}, {5, 0, 7}, {5, 0, 8}, {5, 0, 9},
						  {5, 1, 0}, {5, 1, 1}, {5, 1, 2}, {5, 1, 3}, {5, 1, 4}, {5, 1, 5}, {5, 1, 6}, {5, 1, 7}, {5, 1, 8}, {5, 1, 9},
						  {5, 2, 0}, {5, 2, 1}, {5, 2, 2}, {5, 2, 3}, {5, 2, 4}, {5, 2, 5}, {5, 2, 6}, {5, 2, 7}, {5, 2, 8}, {5, 2, 9},
						  {5, 3, 0}, {5, 3, 1}, {5, 3, 2}, {5, 3, 3}, {5, 3, 4}, {5, 3, 5}, {5, 3, 6}, {5, 3, 7}, {5, 3, 8}, {5, 3, 9},
						  {5, 4, 0}, {5, 4, 1}, {5, 4, 2}, {5, 4, 3}, {5, 4, 4}, {5, 4, 5}, {5, 4, 6}, {5, 4, 7}, {5, 4, 8}, {5, 4, 9},
						  {5, 5, 0}, {5, 5, 1}, {5, 5, 2}, {5, 5, 3}, {5, 5, 4}, {5, 5, 5}, {5, 5, 6}, {5, 5, 7}, {5, 5, 8}, {5, 5, 9},
						  {5, 6, 0}, {5, 6, 1}, {5, 6, 2}, {5, 6, 3}, {5, 6, 4}, {5, 6, 5}, {5, 6, 6}, {5, 6, 7}, {5, 6, 8}, {5, 6, 9},
						  {5, 7, 0}, {5, 7, 1}, {5, 7, 2}, {5, 7, 3}, {5, 7, 4}, {5, 7, 5}, {5, 7, 6}, {5, 7, 7}, {5, 7, 8}, {5, 7, 9},
						  {5, 8, 0}, {5, 8, 1}, {5, 8, 2}, {5, 8, 3}, {5, 8, 4}, {5, 8, 5}, {5, 8, 6}, {5, 8, 7}, {5, 8, 8}, {5, 8, 9},
						  {5, 9, 0}, {5, 9, 1}, {5, 9, 2}, {5, 9, 3}, {5, 9, 4}, {5, 9, 5}, {5, 9, 6}, {5, 9, 7}, {5, 9, 8}, {5, 9, 9},
						  {6, 0, 0}, {6, 0, 1}, {6, 0, 2}, {6, 0, 3}, {6, 0, 4}, {6, 0, 5}, {6, 0, 6}, {6, 0, 7}, {6, 0, 8}, {6, 0, 9},
						  {6, 1, 0}, {6, 1, 1}, {6, 1, 2}, {6, 1, 3}, {6, 1, 4}, {6, 1, 5}, {6, 1, 6}, {6, 1, 7}, {6, 1, 8}, {6, 1, 9},
						  {6, 2, 0}, {6, 2, 1}, {6, 2, 2}, {6, 2, 3}, {6, 2, 4}, {6, 2, 5}, {6, 2, 6}, {6, 2, 7}, {6, 2, 8}, {6, 2, 9},
						  {6, 3, 0}, {6, 3, 1}, {6, 3, 2}, {6, 3, 3}, {6, 3, 4}, {6, 3, 5}, {6, 3, 6}, {6, 3, 7}, {6, 3, 8}, {6, 3, 9},
						  {6, 4, 0}, {6, 4, 1}, {6, 4, 2}, {6, 4, 3}, {6, 4, 4}, {6, 4, 5}, {6, 4, 6}, {6, 4, 7}, {6, 4, 8}, {6, 4, 9},
						  {6, 5, 0}, {6, 5, 1}, {6, 5, 2}, {6, 5, 3}, {6, 5, 4}, {6, 5, 5}, {6, 5, 6}, {6, 5, 7}, {6, 5, 8}, {6, 5, 9},
						  {6, 6, 0}, {6, 6, 1}, {6, 6, 2}, {6, 6, 3}, {6, 6, 4}, {6, 6, 5}, {6, 6, 6}, {6, 6, 7}, {6, 6, 8}, {6, 6, 9},
						  {6, 7, 0}, {6, 7, 1}, {6, 7, 2}, {6, 7, 3}, {6, 7, 4}, {6, 7, 5}, {6, 7, 6}, {6, 7, 7}, {6, 7, 8}, {6, 7, 9},
						  {6, 8, 0}, {6, 8, 1}, {6, 8, 2}, {6, 8, 3}, {6, 8, 4}, {6, 8, 5}, {6, 8, 6}, {6, 8, 7}, {6, 8, 8}, {6, 8, 9},
						  {6, 9, 0}, {6, 9, 1}, {6, 9, 2}, {6, 9, 3}, {6, 9, 4}, {6, 9, 5}, {6, 9, 6}, {6, 9, 7}, {6, 9, 8}, {6, 9, 9},
						  {7, 0, 0}, {7, 0, 1}, {7, 0, 2}, {7, 0, 3}, {7, 0, 4}, {7, 0, 5}, {7, 0, 6}, {7, 0, 7}, {7, 0, 8}, {7, 0, 9},
						  {7, 1, 0}, {7, 1, 1}, {7, 1, 2}, {7, 1, 3}, {7, 1, 4}, {7, 1, 5}, {7, 1, 6}, {7, 1, 7}, {7, 1, 8}, {7, 1, 9},
						  {7, 2, 0}, {7, 2, 1}, {7, 2, 2}, {7, 2, 3}, {7, 2, 4}, {7, 2, 5}, {7, 2, 6}, {7, 2, 7}, {7, 2, 8}, {7, 2, 9},
						  {7, 3, 0}, {7, 3, 1}, {7, 3, 2}, {7, 3, 3}, {7, 3, 4}, {7, 3, 5}, {7, 3, 6}, {7, 3, 7}, {7, 3, 8}, {7, 3, 9},
						  {7, 4, 0}, {7, 4, 1}, {7, 4, 2}, {7, 4, 3}, {7, 4, 4}, {7, 4, 5}, {7, 4, 6}, {7, 4, 7}, {7, 4, 8}, {7, 4, 9},
						  {7, 5, 0}, {7, 5, 1}, {7, 5, 2}, {7, 5, 3}, {7, 5, 4}, {7, 5, 5}, {7, 5, 6}, {7, 5, 7}, {7, 5, 8}, {7, 5, 9},
						  {7, 6, 0}, {7, 6, 1}, {7, 6, 2}, {7, 6, 3}, {7, 6, 4}, {7, 6, 5}, {7, 6, 6}, {7, 6, 7}, {7, 6, 8}, {7, 6, 9},
						  {7, 7, 0}, {7, 7, 1}, {7, 7, 2}, {7, 7, 3}, {7, 7, 4}, {7, 7, 5}, {7, 7, 6}, {7, 7, 7}, {7, 7, 8}, {7, 7, 9},
						  {7, 8, 0}, {7, 8, 1}, {7, 8, 2}, {7, 8, 3}, {7, 8, 4}, {7, 8, 5}, {7, 8, 6}, {7, 8, 7}, {7, 8, 8}, {7, 8, 9},
						  {7, 9, 0}, {7, 9, 1}, {7, 9, 2}, {7, 9, 3}, {7, 9, 4}, {7, 9, 5}, {7, 9, 6}, {7, 9, 7}, {7, 9, 8}, {7, 9, 9},
						  {8, 0, 0}, {8, 0, 1}, {8, 0, 2}, {8, 0, 3}, {8, 0, 4}, {8, 0, 5}, {8, 0, 6}, {8, 0, 7}, {8, 0, 8}, {8, 0, 9},
						  {8, 1, 0}, {8, 1, 1}, {8, 1, 2}, {8, 1, 3}, {8, 1, 4}, {8, 1, 5}, {8, 1, 6}, {8, 1, 7}, {8, 1, 8}, {8, 1, 9},
						  {8, 2, 0}, {8, 2, 1}, {8, 2, 2}, {8, 2, 3}, {8, 2, 4}, {8, 2, 5}, {8, 2, 6}, {8, 2, 7}, {8, 2, 8}, {8, 2, 9},
						  {8, 3, 0}, {8, 3, 1}, {8, 3, 2}, {8, 3, 3}, {8, 3, 4}, {8, 3, 5}, {8, 3, 6}, {8, 3, 7}, {8, 3, 8}, {8, 3, 9},
						  {8, 4, 0}, {8, 4, 1}, {8, 4, 2}, {8, 4, 3}, {8, 4, 4}, {8, 4, 5}, {8, 4, 6}, {8, 4, 7}, {8, 4, 8}, {8, 4, 9},
						  {8, 5, 0}, {8, 5, 1}, {8, 5, 2}, {8, 5, 3}, {8, 5, 4}, {8, 5, 5}, {8, 5, 6}, {8, 5, 7}, {8, 5, 8}, {8, 5, 9},
						  {8, 6, 0}, {8, 6, 1}, {8, 6, 2}, {8, 6, 3}, {8, 6, 4}, {8, 6, 5}, {8, 6, 6}, {8, 6, 7}, {8, 6, 8}, {8, 6, 9},
						  {8, 7, 0}, {8, 7, 1}, {8, 7, 2}, {8, 7, 3}, {8, 7, 4}, {8, 7, 5}, {8, 7, 6}, {8, 7, 7}, {8, 7, 8}, {8, 7, 9},
						  {8, 8, 0}, {8, 8, 1}, {8, 8, 2}, {8, 8, 3}, {8, 8, 4}, {8, 8, 5}, {8, 8, 6}, {8, 8, 7}, {8, 8, 8}, {8, 8, 9},
						  {8, 9, 0}, {8, 9, 1}, {8, 9, 2}, {8, 9, 3}, {8, 9, 4}, {8, 9, 5}, {8, 9, 6}, {8, 9, 7}, {8, 9, 8}, {8, 9, 9},
						  {9, 0, 0}, {9, 0, 1}, {9, 0, 2}, {9, 0, 3}, {9, 0, 4}, {9, 0, 5}, {9, 0, 6}, {9, 0, 7}, {9, 0, 8}, {9, 0, 9},
						  {9, 1, 0}, {9, 1, 1}, {9, 1, 2}, {9, 1, 3}, {9, 1, 4}, {9, 1, 5}, {9, 1, 6}, {9, 1, 7}, {9, 1, 8}, {9, 1, 9},
						  {9, 2, 0}, {9, 2, 1}, {9, 2, 2}, {9, 2, 3}, {9, 2, 4}, {9, 2, 5}, {9, 2, 6}, {9, 2, 7}, {9, 2, 8}, {9, 2, 9},
						  {9, 3, 0}, {9, 3, 1}, {9, 3, 2}, {9, 3, 3}, {9, 3, 4}, {9, 3, 5}, {9, 3, 6}, {9, 3, 7}, {9, 3, 8}, {9, 3, 9},
						  {9, 4, 0}, {9, 4, 1}, {9, 4, 2}, {9, 4, 3}, {9, 4, 4}, {9, 4, 5}, {9, 4, 6}, {9, 4, 7}, {9, 4, 8}, {9, 4, 9},
						  {9, 5, 0}, {9, 5, 1}, {9, 5, 2}, {9, 5, 3}, {9, 5, 4}, {9, 5, 5}, {9, 5, 6}, {9, 5, 7}, {9, 5, 8}, {9, 5, 9},
						  {9, 6, 0}, {9, 6, 1}, {9, 6, 2}, {9, 6, 3}, {9, 6, 4}, {9, 6, 5}, {9, 6, 6}, {9, 6, 7}, {9, 6, 8}, {9, 6, 9},
						  {9, 7, 0}, {9, 7, 1}, {9, 7, 2}, {9, 7, 3}, {9, 7, 4}, {9, 7, 5}, {9, 7, 6}, {9, 7, 7}, {9, 7, 8}, {9, 7, 9},
						  {9, 8, 0}, {9, 8, 1}, {9, 8, 2}, {9, 8, 3}, {9, 8, 4}, {9, 8, 5}, {9, 8, 6}, {9, 8, 7}, {9, 8, 8}, {9, 8, 9},
						  {9, 9, 0}, {9, 9, 1}, {9, 9, 2}, {9, 9, 3}, {9, 9, 4}, {9, 9, 5}, {9, 9, 6}, {9, 9, 7}, {9, 9, 8}, {9, 9, 9}};

/**
 * instellen Neo-M8 1MHz 10% duty bij zowel Fix geen Fix GPS
 */
int8_t M8N_init[] = {0xB5, 0x62, 0x06, 0x31, 0x20, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x42, 0x0F, 0x00, 0x40, 0x42,
		             0x0F, 0x00, 0x9A, 0x99, 0x99, 0x19, 0x9A, 0x99, 0x99, 0x19, 0x00, 0x00, 0x00, 0x00, 0x6F, 0x00, 0x00, 0x00, 0xB3, 0xB2,
			         0xB5, 0x62, 0x06, 0x31, 0x01, 0x00, 0x00, 0x38, 0xE5};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  /* Start timers */
  /*HAL_TIM_Base_Start_IT(&htim1);*/ /* timer 1 wordt gestart met startknop */
  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_Base_Start_IT(&htim3);
  HAL_TIM_Base_Start_IT(&htim4);

  HAL_NVIC_DisableIRQ(EXTI0_IRQn);
  HAL_NVIC_DisableIRQ(EXTI1_IRQn);
  HAL_NVIC_DisableIRQ(EXTI2_IRQn);
  HAL_NVIC_DisableIRQ(EXTI3_IRQn);

/* effe wachten */
  HAL_Delay(1000);

/* instellen NEO-M8 op 1Mhz 10% cycle */
  HAL_UART_Transmit(&huart2,(uint8_t *)M8N_init, sizeof(M8N_init), 100);
  HAL_Delay(2000);

  /* initialiseren LED display */
  uint8_t buf[1];
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0xff;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_Delay(10);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x09;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0xff;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x0a;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x01;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x0b;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x07;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x0c;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x01;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x01;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x02;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x03;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00 | 0x80;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x04;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x05;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00 | 0x80;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x06;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x07;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00 | 0x80;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_GPIO_WritePin(SPI_1_CS, 0);
  buf[0] = 0x08;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  buf[0] = 0x00;
  HAL_SPI_Transmit(&hspi1, buf, 1, 10);
  HAL_GPIO_WritePin(SPI_1_CS, 1);
  HAL_Delay(2000);

  __HAL_TIM_SET_COUNTER(&htim1, 0);
  __HAL_TIM_SET_COUNTER(&htim2, 0);
  __HAL_TIM_SET_COUNTER(&htim3, 0);
  __HAL_TIM_SET_COUNTER(&htim4, 0);
  chrono.micro_seconden =__HAL_TIM_GET_COUNTER(&htim1);
  chrono.milli_seconden =__HAL_TIM_GET_COUNTER(&htim2);
  chrono.seconden =__HAL_TIM_GET_COUNTER(&htim3);
  chrono.minuten =__HAL_TIM_GET_COUNTER(&htim4);
  chrono.uren = 0;

  HAL_NVIC_EnableIRQ(EXTI0_IRQn);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 12;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/*
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim1){

}
*/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
